var dailyIncome: [Double] = [50, 65, 60, 58, 70, 87, 100]

if let maxIncome = dailyIncome.max() {
    print(maxIncome)
}
