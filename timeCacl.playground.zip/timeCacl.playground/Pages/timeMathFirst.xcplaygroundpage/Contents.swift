import Foundation  // Библиотека для работы с датами и другими стандартными функциями

// Структура для фиксированных расходов
struct FixedExpense {
    let amount: Double   // Сумма фиксированного расхода
    let day: Int         // День месяца, когда нужно оплатить (например, 12-е число)
    let repeatsMonthly: Bool  // Повторяется ли этот расход каждый месяц
}

// Функция для вычисления даты окончания капитала с учётом фиксированных расходов
func calculateEndDate(startDate: String, capital: Double, dailyExpense: Double, fixedExpenses: [FixedExpense]) -> (Date?, Double) {
    guard dailyExpense > 0 else {
        print("Ежедневные расходы должны быть больше 0")
        return (nil, 0)
    }

    // Форматтер для преобразования строки в дату
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "yyyy-MM-dd"  // Формат даты

    // Преобразуем строку с датой в объект Date
    guard let currentDate = dateFormatter.date(from: startDate) else {
        print("Ошибка: неверный формат даты.")
        return (nil, 0)
    }

    var remainingCapital = capital  // Текущий остаток капитала
    var currentDay = currentDate    // Текущая дата

    // Пока есть деньги, продолжаем вычисления
    while remainingCapital > 0 {
        // Проверяем фиксированные расходы
        for expense in fixedExpenses {
            // Проверяем, совпадает ли текущий день с фиксированным днем
            let components = Calendar.current.dateComponents([.day, .month], from: currentDay)
            
            if components.day == expense.day {
                remainingCapital -= expense.amount  // Вычитаем фиксированный расход
            }
        }

        // Вычитаем ежедневные расходы
        remainingCapital -= dailyExpense

        // Если капитал закончился, возвращаем текущую дату и остаток
        if remainingCapital <= 0 {
            return (currentDay, remainingCapital)
        }

        // Переходим к следующему дню
        guard let nextDay = Calendar.current.date(byAdding: .day, value: 1, to: currentDay) else {
            return (nil, 0)
        }
        currentDay = nextDay  // Обновляем текущий день
    }

    return (nil, remainingCapital)  // Если капитал не закончится
}

// Пример фиксированных расходов
let fixedExpenses = [
    FixedExpense(amount: 218, day: 12, repeatsMonthly: true),  // Кредит, повторяется каждый месяц 12-го числа
    FixedExpense(amount: 624, day: 15, repeatsMonthly: true),  // Аренда, повторяется каждый месяц 15-го числа
    FixedExpense(amount: 64, day: 20, repeatsMonthly: true),  // GPT, повторяется каждый месяц 15-го числа
    FixedExpense(amount: 6.5, day: 22, repeatsMonthly: true),   // Internet, повторяется каждый месяц 22-го числа
    FixedExpense(amount: 40, day: 25, repeatsMonthly: true),  // Haircut, повторяется каждый месяц 25-го числа
    FixedExpense(amount: 6.5, day: 28, repeatsMonthly: true),   // Bank, повторяется каждый месяц 28-го числа
    FixedExpense(amount: 2.8, day: 30, repeatsMonthly: true)   // iCloud, повторяется каждый месяц 15-го числа
]

// Пример использования
let startDate = "2024-09-14"   // Вводим текущую дату вручную в формате ГГГГ-ММ-ДД
let capital = 659.26        // Начальный капитал
let dailyExpense = 5.0      // Ежедневные расходы

// Вызываем функцию для вычисления даты окончания денег
let (endDate, finalCapital) = calculateEndDate(startDate: startDate, capital: capital, dailyExpense: dailyExpense, fixedExpenses: fixedExpenses)

if let endDate = endDate {
    let dateFormatter = DateFormatter()
    dateFormatter.dateStyle = .medium
    print("Дата окончания денег: \(dateFormatter.string(from: endDate)), остаток: \(finalCapital)")
} else {
    print("Капитала хватит навсегда.")
}

